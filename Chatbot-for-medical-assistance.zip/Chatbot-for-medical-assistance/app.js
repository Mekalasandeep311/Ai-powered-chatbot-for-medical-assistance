const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const path = require("path");

const app = express();

// MongoDB connection
mongoose.connect("mongodb+srv://avaneesh:mogilicherla@cluster0.tgbro.mongodb.net/med_chatbot?retryWrites=true&w=majority&appName=Cluster0", { 
    useNewUrlParser: true, 
    useUnifiedTopology: true 
})
.then(() => console.log("Connected to MongoDB"))
.catch(err => console.error("Could not connect to MongoDB", err));

// User schema and model
const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
});

const User = mongoose.model("User", userSchema);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Serve static files (like images, CSS) from the 'public' and 'static' folders
app.use(express.static(path.join(__dirname, 'public')));   // Serves 'public' folder
app.use(express.static(path.join(__dirname, 'static')));   // Serves 'static' folder

// Routes
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/Home.html');  // Serve Home.html from root folder
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '/Login.html'));  // Serve Login.html from root folder
});

app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, '/Signup.html')); // Serve Signup.html from root folder
});

// Signup Route
app.post("/signup", async (req, res) => {
    const { username, password } = req.body;
    try {
        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(400).send("User already exists");
        }
        const newUser = new User({ username, password });
        await newUser.save();
        res.status(200).send("Signup successful");
    } catch (error) {
        res.status(500).send("Error signing up");
    }
});

// Login Route
app.post("/login", async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username, password });
        if (!user) {
            return res.status(401).send("Invalid credentials");
        }
        res.status(200).send("Login successful");
    } catch (error) {
        res.status(500).send("Error logging in");
    }
});

// Start the server
app.listen(4000, () => {
    console.log("Server is running on http://localhost:4000");
});
